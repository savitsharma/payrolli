package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.AllowancesRepository;
import com.example.demo.dto.Allowancesdto;

import com.example.demo.entities.Allowances;
@Service
public class AllowancesService {
	
	@Autowired
	AllowancesRepository allowancesRepository;
	
	public void saveAllowances(Allowancesdto allowancesdto)
	{
		allowancesRepository.save(allowancesdtotoAllowances(allowancesdto));
	}
	
	 public List<Allowancesdto> getAllAllowance(){

	        List<Allowances> listAllowances= this.allowancesRepository.findAll();

	

    List<Allowancesdto> allowancesDtoList = listAllowances.stream().map(emp -> this.allowancestoallowancesdto(emp)).collect(Collectors.toList());
	return allowancesDtoList;

	 }	
	
	
	
	 public void deleteAllowance(int empId){

	       allowancesRepository.deleteById(empId);

	    }
	    public Allowancesdto updateAllowances(Allowancesdto allowancesdto)
	    {
	    allowancesRepository.save(allowancesdtotoAllowances(allowancesdto));
	    return allowancesdto;

	    }


	   
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 public Allowances allowancesdtotoAllowances(Allowancesdto allowancesdto)
	    {
	        Allowances allowances=new Allowances();

	        allowances.setId(allowancesdto.getId());
	        allowances.setAllowancesDescription(allowancesdto.getAllowancesDescription());
	        

	       
	        return allowances;
	    }

	    public Allowancesdto allowancestoallowancesdto(Allowances allowances)
	    {
	        Allowancesdto allowancesdto= new Allowancesdto();

	      allowancesdto.setId(allowances.getId());
	      allowancesdto.setAllowancesDescription(allowances.getAllowancesDescription());
	        return allowancesdto;
	    }

	




}

