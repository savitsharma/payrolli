package com.example.demo.controller;


	

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

    import com.example.demo.dto.Employeedto;
    import com.example.demo.services.EmployeeServices;

	
	@RestController
	public class EmployeeControlle {
		
		@Autowired
		EmployeeServices employeeService;
		
		
		@PostMapping("/employee")
		 public Employeedto saveEmp(@RequestBody Employeedto employeeDto)
	 {
	    employeeService.saveEmployee(employeeDto);

	     return employeeDto;

	 }
		
		@GetMapping("/employee")
	public List<Employeedto> getEmployee()
	{
	    List<Employeedto> allEmployee = employeeService.getAllEmployee();
	    return allEmployee ;
	}

		 @GetMapping("/employee/{employeeId}")
		 public Employeedto getEmployeeById(@PathVariable("employeeId") int Id)
		    {
		        return employeeService.employeeById(Id);
		    }
		 	
		 
		 @DeleteMapping("/employee/{employeeId}")
		    public void deleteEmp(@PathVariable("employeeId") int id){
		        employeeService.deleteEmployee(id);
		    }

		
		



		
		
		

	}



