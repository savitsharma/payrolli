package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Repository.EmployeeDeductionRepository;
import com.example.demo.dto.Deductiondto;
import com.example.demo.services.DeductionServices;
public class DeductionController {
	
	@Autowired
	EmployeeDeductionRepository employeeDeductionRepository;
	
	@Autowired
	DeductionServices deductionServices;
	
	
	@PostMapping("/deductions")
	public ResponseEntity<Deductiondto> saveDeduction(@RequestBody Deductiondto deductiondto){
		
	     deductionServices.saveDeduction(deductiondto);
	     
		
		return new ResponseEntity<>(deductiondto,HttpStatus.CREATED);
		
	}

	    @DeleteMapping("/dedution/{deductionId}")
	    public void delete(@PathVariable("allowancesId") int id){
	      
	    	
	          deductionServices.deleteDedution(id);
	    }
	  
	  


	    @PutMapping("/deduction")
	    public ResponseEntity<Deductiondto> updateall(@RequestBody Deductiondto deductiondto)
	    {
	       deductionServices.updateDedution(deductiondto);
	        return new ResponseEntity<>(deductiondto, HttpStatus.ACCEPTED);
	    }


}
