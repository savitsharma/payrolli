package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.PayrollItemRepository;
import com.example.demo.dto.Payroll_Itemdto;
import com.example.demo.entities.Payroll_Item;
@Service
public class Payroll_itemServices {
	
	@Autowired
	PayrollItemRepository payrollItemRepository;
	
	public void savePayrollitem(Payroll_Itemdto payroll_Itemdto)
	{
		payrollItemRepository.save(payroll_Itemdtotopayroll_Item(payroll_Itemdto));
	}
	
	 public List<Payroll_Itemdto> getAllpayrollitem(){

	        List<Payroll_Item> listpayrollitem= this.payrollItemRepository.findAll();

	

    List<Payroll_Itemdto> payrollitemdtoList = listpayrollitem.stream().map(emp -> this.payroll_Itemtopayroll_Itemdto(emp)).collect(Collectors.toList());
	return payrollitemdtoList;

	 }	
	
	
	
	 public void deletePayrollitem(int empId){

	     payrollItemRepository.deleteById(empId);

	    }
	    public Payroll_Itemdto updatePayrollitem(Payroll_Itemdto payroll_Itemdto)
	    {
	    payrollItemRepository.save(payroll_Itemdtotopayroll_Item(payroll_Itemdto));
	    return payroll_Itemdto;

	    }


	 public Payroll_Item payroll_Itemdtotopayroll_Item(Payroll_Itemdto payroll_Itemdto)
	    {
	          Payroll_Item payrollItem =new Payroll_Item();
	          
	          payrollItem.setId(payroll_Itemdto.getId());;
		      payrollItem.setPayrollid(payroll_Itemdto.getPayrollid());
		      payrollItem.setEmployeeid(payroll_Itemdto.getEmployeeid());
		      payrollItem.setPresent(payroll_Itemdto.getPresent());
		      payrollItem.setAbsent(payroll_Itemdto.getAbsent());
		      payrollItem.setLate(payroll_Itemdto.getLate());
		      payrollItem.setSalary(payroll_Itemdto.getSalary());
		      payrollItem.setAllowance_amount(payroll_Itemdto.getAllowance_amount());
		      payrollItem.setAllownces_type(payroll_Itemdto.getAllownces_type());
		      payrollItem.setDeduction_amouont(payroll_Itemdto.getDeduction_amouont());
		      payrollItem.setDeductions(payroll_Itemdto.getDeductions());
		      payrollItem.setGross_net(payroll_Itemdto.getGross_net());
		      payrollItem.setDate_created(payroll_Itemdto.getDate_created());

	       
	        return payrollItem;
	    }

	    public Payroll_Itemdto payroll_Itemtopayroll_Itemdto(Payroll_Item payroll_Item)
	    {
	        Payroll_Itemdto payrollItem= new Payroll_Itemdto();

	      payrollItem.setId(payroll_Item.getId());;
	      payrollItem.setPayrollid(payroll_Item.getPayrollid());
	      payrollItem.setEmployeeid(payroll_Item.getEmployeeid());
	      payrollItem.setPresent(payroll_Item.getPresent());
	      payrollItem.setAbsent(payroll_Item.getAbsent());
	      payrollItem.setLate(payroll_Item.getLate());
	      payrollItem.setSalary(payroll_Item.getSalary());
	      payrollItem.setAllowance_amount(payroll_Item.getAllowance_amount());
	      payrollItem.setAllownces_type(payroll_Item.getAllownces_type());
	      payrollItem.setDeduction_amouont(payroll_Item.getDeduction_amouont());
	      payrollItem.setDeductions(payroll_Item.getDeductions());
	      payrollItem.setGross_net(payroll_Item.getGross_net());
	      payrollItem.setDate_created(payroll_Item.getDate_created());
	        
	      return payrollItem;
	        
	    }
	

}
