package com.example.demo.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Payroll_Item;



public interface PayrollItemRepository extends JpaRepository <Payroll_Item, Integer>{
		


	}
	
