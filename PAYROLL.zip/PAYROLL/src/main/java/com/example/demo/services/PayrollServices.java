package com.example.demo.services;


	

	import java.util.List;
	import java.util.stream.Collectors;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

import com.example.demo.Repository.PayRollRepository;

import com.example.demo.dto.PayRolldto;

import com.example.demo.entities.PayRoll;

	@Service
	public class PayrollServices {
		
		
		@Autowired
		 PayRollRepository payrollRepository;
		
		
		public void savePayroll(PayRolldto payrollDto) {
			payrollRepository.save(payrollDtoToPayroll(payrollDto));
		
		}
		
		public List<PayRolldto> getAllPayroll (){
			List<PayRoll> listPayroll = this.payrollRepository.findAll();
			List<PayRolldto> payrollDtoList = listPayroll.stream().map(emp -> this.payrollToPayrollDto(emp)).collect(Collectors.toList());
			
			return payrollDtoList;
			
		}
		
			public void deletePayroll(int Id) {
			
				payrollRepository.deleteById(Id);
		}
			
			public PayRoll savePayroll(PayRoll payroll) {
				return payrollRepository.save(payroll);
			}
			
			 public PayRolldto payrollById(Integer Id)
			    {
			        PayRoll payroll = this.payrollRepository.findById(Id).get();
			        // Optional<Employee> byId = employeeReposatory.findById(employeeId);
			        return this.payrollToPayrollDto(payroll);

			    }


		
		
		
		public PayRoll payrollDtoToPayroll(PayRolldto payrollDto) {
			
			PayRoll payroll = new PayRoll();
			payroll.setId(payrollDto.getId());
			payroll.setDate_From(payrollDto.getDate_From());
			payroll.setDate_To(payrollDto.getDate_To());
			payroll.setDateCerated(payrollDto.getDateCerated());
			payroll.setRef_No(payrollDto.getRef_No());
			payroll.setStatus(payrollDto.getStatus());
			payroll.setType(payrollDto.getType());
			
			return payroll;
			
		}
		
		public PayRolldto payrollToPayrollDto(PayRoll payroll) {
			
			PayRolldto payrollDto = new PayRolldto();
			payroll.setId(payroll.getId());
			payroll.setDate_From(payroll.getDate_From());
			payroll.setDate_To(payroll.getDate_To());
			payroll.setDateCerated(payroll.getDateCerated());
			payroll.setStatus(payroll.getStatus());
			payroll.setType(payroll.getType());
			payroll.setRef_No(payroll.getRef_No());
			
			return payrollDto;
			
		}

	}


