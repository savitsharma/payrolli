package com.example.demo.services;


	import java.util.List;
	import java.util.stream.Collectors;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.example.demo.Repository.PositionRepository;
    import com.example.demo.dto.Positiondto;
    import com.example.demo.entities.Position;

	@Service

	public class PositionServices {
		@Autowired
		
		PositionRepository postionRepository;
		
		public void savePosition(Positiondto positionDto) {
			
			postionRepository.save(positionDtoToPosition(positionDto));
			
			
			
		}
		
		public Position positionDtoToPosition(Positiondto positionDto) {
			 
			Position pos=new Position();
			pos.setDepartment_id(positionDto.getDepartment_id());
			pos.setName(positionDto.getName());
			
			return pos;
			
		}
		
		public Positiondto positionToPositionDto(Position position) {
			
			Positiondto pdo=new Positiondto();
			pdo.setDepartment_id(position.getDepartment_id());
			pdo.setName(position.getName());
			return pdo;
			
			
		}
		public void deletePosition(int department_id) {
			postionRepository.deleteById(department_id);
			
			
		}
		public List<Positiondto>getAllDeductionDto(){
			List<Position> position=this.postionRepository.findAll();
			List<Positiondto> postionDto=position.stream().map(po ->this.positionToPositionDto(po)).collect(Collectors.toList());
			return postionDto;
			
			
		}
		public Positiondto updateDeduction(Positiondto positionDto) {
			
			postionRepository.save(positionDtoToPosition(positionDto));
			return positionDto;
		}
		

	}


