package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="allowances")
public class Allowances {
	
	@Id
	private int id;
	private String allowancesDescription;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAllowancesDescription() {
		return allowancesDescription;
	}
	public void setAllowancesDescription(String allowancesDescription) {
		this.allowancesDescription = allowancesDescription;
	}
	@Override
	public String toString() {
		return "Allowances [id=" + id + ", allowancesDescription=" + allowancesDescription + "]";
	}

	
	
}
