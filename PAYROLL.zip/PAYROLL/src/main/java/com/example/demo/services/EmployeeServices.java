package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.dto.Employeedto;
import com.example.demo.entities.Employee;

@Service
public class EmployeeServices {

	

	
		
		@Autowired
		EmployeeRepository employeeRepository;
		
		public void saveEmployee(Employeedto employeeDto) {
			employeeRepository.save(employeeDtoToEmployee(employeeDto));
		
		}
		
		public List<Employeedto> getAllEmployee(){
			List<Employee> listEmployee = this.employeeRepository.findAll();
			List<Employeedto> employeeDtoList = listEmployee.stream().map(emp -> this.employeeToEmployeeDto(emp)).collect(Collectors.toList());
			
			return employeeDtoList;
			
		}
		
			public void deleteEmployee(int Id) {
			
				employeeRepository.deleteById(Id);
		}
			
			public Employee saveEmployee(Employee employee) {
				return employeeRepository.save(employee);
			}
			
			 public Employeedto employeeById(Integer Id)
			    {
			        Employee employee = this.employeeRepository.findById(Id).get();
			        // Optional<Employee> byId = employeeReposatory.findById(employeeId);
			        return this.employeeToEmployeeDto(employee);

			    }

		
		
		
		
		public Employee employeeDtoToEmployee(Employeedto employeeDto) {
			
			Employee employee = new Employee();
			employee.setId(employeeDto.getId());
			employee.setDepId(employeeDto.getDepId());
			employee.setEmpId(employee.getEmpId());
			employee.setFiistName(employeeDto.getFiistName());
			employee.setLastName(employeeDto.getLastName());
			employee.setMiddleName(employeeDto.getMiddleName());
			employee.setPositionId(employeeDto.getPositionId());
			employee.setSalary(employeeDto.getSalary());
			
			return employee;
			
			
		}
		
		
		public Employeedto employeeToEmployeeDto(Employee employee) {
			Employeedto employeeDto = new Employeedto();
			employeeDto.setDepId(employee.getDepId());
			employeeDto.setEmpId(employee.getEmpId());
			employeeDto.setFiistName(employee.getFiistName());
			employeeDto.setId(employee.getId());
			employeeDto.setLastName(employee.getLastName());
			employeeDto.setMiddleName(employee.getMiddleName());
			
			employeeDto.setPositionId(employee.getPositionId());
			employeeDto.setSalary(employee.getSalary());
			
			return employeeDto;
		}

	}

