package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.EmpeloyeDeductiondto;
import com.example.demo.services.EmployeeDeductionServices;

@RestController
public class EmployeeDeductionController {
	
	   @Autowired
       EmployeeDeductionServices deductinServices;
 
	@PostMapping("/empdeduction")
 public ResponseEntity<EmpeloyeDeductiondto>saveDeduction(@RequestBody EmpeloyeDeductiondto empeloyeDeductiondto){
	 
	 deductinServices.saveEmp(empeloyeDeductiondto);
	 return new ResponseEntity<>(empeloyeDeductiondto,HttpStatus.CREATED); 
 }
 @DeleteMapping("/empdeduction/{id}")
 public void deleteDeduction(@PathVariable("id")int id ) {
	 
	 deductinServices.deleteempdeduction(id);	 
	 
 }
// @PutMapping("/empdeduction") 
// public ResponseEntity<Deductiondto>updateall(@RequestBody Deductiondto deductionDto){
	 
//	 deductinServices.upd(deductionDto);
//	 return new ResponseEntity<>(deductionDto,HttpStatus.CREATED);
 }
 
 
 
