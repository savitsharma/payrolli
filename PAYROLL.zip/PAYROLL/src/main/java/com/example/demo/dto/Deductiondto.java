package com.example.demo.dto;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name=" deduction")
public class Deductiondto {
	    @Id
        private int id;
		private double deduction;
		private String description;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public double getDeduction() {
			return deduction;
		}
		public void setDeduction(double deduction) {
			this.deduction = deduction;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		@Override
		public String toString() {
			return "Deduction [id=" + id + ", deduction=" + deduction + ", description=" + description + "]";
		}
		

	}


