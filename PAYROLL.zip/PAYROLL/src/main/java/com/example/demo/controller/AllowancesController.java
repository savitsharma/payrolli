package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Allowancesdto;
import com.example.demo.services.AllowancesService;

@RestController
public class AllowancesController {
	
	@Autowired
	AllowancesService allowancesService;
	
	
	@PostMapping("/allowances")
	public ResponseEntity<Allowancesdto> saveEmp(@RequestBody Allowancesdto allowancesdto){
		allowancesService.saveAllowances(allowancesdto);
		
		return new ResponseEntity<>(allowancesdto,HttpStatus.CREATED);
		
	}

	    @DeleteMapping("/allowances/{allowancesId}")
	    public void deleteAllo(@PathVariable("allowancesId") int id){
	      
	    	
	    	allowancesService.deleteAllowance(id);
	    }
	  
	  


	    @PutMapping("/allowances")
	    public ResponseEntity<Allowancesdto> updateall(@RequestBody Allowancesdto allowancesdto)
	    {
	       allowancesService.updateAllowances(allowancesdto);
	        return new ResponseEntity<>(allowancesdto, HttpStatus.ACCEPTED);
	    }

		
	
	

}
