package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.EmployeeDeductionRepository;
import com.example.demo.dto.Deductiondto;
import com.example.demo.dto.EmpeloyeDeductiondto;
import com.example.demo.entities.EmployeeDeduction;

@Service
public class EmployeeDeductionServices {
	
	
		
		
		@Autowired
		 EmployeeDeductionRepository employeeDeductionRepository;
		
		public void saveEmp(EmpeloyeDeductiondto empDeductiondto) {
		      employeeDeductionRepository.save(employeeDeductiondtotoempDeduction(empDeductiondto));
		
		}
		
		public List<EmpeloyeDeductiondto> getAllPayroll (){
			List<EmployeeDeduction> listPayroll = this.employeeDeductionRepository.findAll();
			List<EmpeloyeDeductiondto> empDeductions = listPayroll.stream().map(emp -> this.empeloyeeDeductiontoEmployeeDeductiondto(emp)).collect(Collectors.toList());
			
			return empDeductions;
			
		}
		
			public void deleteempdeduction(int Id) {
			
				employeeDeductionRepository.deleteById(Id);
		}
			
			public EmployeeDeduction savePayroll(EmployeeDeduction employeeDeduction) {
				return employeeDeductionRepository.save(employeeDeduction);
			}
			
			 public EmpeloyeDeductiondto payrollById(Integer Id)
			    {
			        EmployeeDeduction employeeDeduction = this.employeeDeductionRepository.findById(Id).get();
			        // Optional<Employee> byId = employeeReposatory.findById(employeeId);
			        return this.empeloyeeDeductiontoEmployeeDeductiondto(employeeDeduction);

			    }


		
		
		
		public EmployeeDeduction employeeDeductiondtotoempDeduction(EmpeloyeDeductiondto employeDeductiondto ) {
			
			EmployeeDeduction empDeduction = new EmployeeDeduction();
			empDeduction.setId(employeDeductiondto.getId());;
			empDeduction.setEmp_Id(employeDeductiondto.getEmp_Id());
			empDeduction.setType(employeDeductiondto.getType());
			empDeduction.setDate_created(employeDeductiondto.getDate_created());
			empDeduction.setEffective_Date(employeDeductiondto.getEffective_Date());
			empDeduction.setDeduction_Id(employeDeductiondto.getDeduction_Id());
			empDeduction.setAmmount(employeDeductiondto.getAmmount());
		
			return empDeduction;
			
		}
		
		public EmpeloyeDeductiondto empeloyeeDeductiontoEmployeeDeductiondto (EmployeeDeduction employeeDeduction) {
			
			EmpeloyeDeductiondto empDeduction = new EmpeloyeDeductiondto();
			empDeduction.setEmp_Id(empDeduction.getEmp_Id());
			empDeduction.setType(empDeduction.getType());
			empDeduction.setDate_created(empDeduction.getDate_created());
			empDeduction.setEffective_Date(empDeduction.getEffective_Date());
			empDeduction.setDeduction_Id(empDeduction.getDeduction_Id());
			empDeduction.setAmmount(empDeduction.getAmmount());
		
		
			
			return empDeduction;
			
		}

	}





