package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.DeductionRepository;
import com.example.demo.dto.Deductiondto;
import com.example.demo.entities.Deduction;

@Service
public class DeductionServices {
	
	

	@Autowired
	DeductionRepository deductionRepository;
	
	public void saveDeduction(Deductiondto deductiondto)
	{
		deductionRepository.save(deductiondtotoDeduction(deductiondto));
	}
	
	 public List<Deductiondto> getAllDeduction(){

	        List<Deduction> listDeduction= this.deductionRepository.findAll();

	

    List<Deductiondto> dedductiondtoList = listDeduction.stream().map(emp -> this.deductiontoallowancesdto(emp)).collect(Collectors.toList());
	return dedductiondtoList;

	 }	
	
	
	
	 public void deleteDedution(int empId){

	       deductionRepository.deleteById(empId);

	    }
	    public Deductiondto updateDedution(Deductiondto deductiondto)
	    {
	    deductionRepository.save(deductiondtotoDeduction(deductiondto));
	    return deductiondto;

	    }


	 public Deduction deductiondtotoDeduction(Deductiondto deductiondto)
	    {
	          Deduction deduction =new Deduction();

	        deduction.setId(deductiondto.getId());
	        deduction.setDeduction(deductiondto.getDeduction());
            deduction.setDescription(deductiondto.getDescription());        

	       
	        return deduction;
	    }

	    public Deductiondto deductiontoallowancesdto(Deduction deduction)
	    {
	        Deductiondto deductiondto= new Deductiondto();

	      deductiondto.setId(deduction.getId());
	      deductiondto.setDeduction(deduction.getDeduction());
	        return deductiondto;
	        
	    }


}
